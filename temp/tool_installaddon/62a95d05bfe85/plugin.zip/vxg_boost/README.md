This plugin package is part of Corporate LMS package developed by Veloxnet and Trimenta Ltd.

If you are interested in the complete inexpensive corporate package, write to lms@veloxnet.hu.

Requirements
------------

Moodle 3.4 or greater.

Installation
------------

Simply install from the moodle.org/plugins or download and copy it to the appropriate plugin directory.
https://docs.moodle.org/39/en/Installing_plugins


Functionality
-------------
Please watch the video on the moodle.org/plugins.


License
-------

Licensed under the [GNU GPL License](http://www.gnu.org/copyleft/gpl.html).
